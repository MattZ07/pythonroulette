import os
import random
import time
import winsound


def clear():
  os.system('cls')


def lblprint(text):
  for i in (range(len(text))):
    winsound.PlaySound('beep.wav', winsound.SND_ASYNC)
    print(text[i], end="", flush=True)
    time.sleep(0.05)
  print()


def abvprint(text, lbl):
  print()
  if lbl == 1:
    for i in (range(len(text))):
      winsound.PlaySound('beep.wav', winsound.SND_ASYNC)
      print(text[i], end="", flush=True)
      time.sleep(0.05)
  else:
    print(text, end="")
  print()


def blwprint(text, lbl):
  if lbl == 1:
    for i in (range(len(text))):
      winsound.PlaySound('beep.wav', winsound.SND_ASYNC)
      print(text[i], end="", flush=True)
      time.sleep(0.05)
  else:
    print(text, end="")
  print()
  print()


def xlprint(text, lbl):
  print()
  if lbl == 1:
    for i in (range(len(text))):
      winsound.PlaySound('beep.wav', winsound.SND_ASYNC)
      print(text[i], end="", flush=True)
      time.sleep(0.05)
  else:
    print(text, end="")
  print()
  print()


def dash():
  print()
  print("-------------------")
  print()


def main():
  clear()
  lblprint("PYTHON ROULETTE")
  dash()
  blwprint("Select a mode: ", 1)
  print("1 - Buckshot roulette")
  print("2 - Russian Roulette")
  blwprint("3 - Custom", 0)
  progress = 0
  global mode
  while progress == 0:
    mode = input("Your choice: ")
    try:
      if int(mode) < 1 or int(mode) > 3:
        progress = 0
        xlprint("Input was out of bounds.", 1)
      else:
        progress = 1
    except:
      progress = 0
      xlprint("Invalid input type.", 1)
  global hp
  global magsize
  global showhealth
  global showrounds
  global selfblankskipsopp
  global canshootself
  global canshootopp
  global maxlivecount
  global maxblankcount
  clear()
  if mode == '1':
    hp = 5
    magsize = 6
    showhealth = 1
    showrounds = 1
    selfblankskipsopp = 1
    canshootself = 1
    canshootopp = 1
    maxlivecount = 'default'
    maxblankcount = 'default'
  elif mode == '2':
    hp = 1
    magsize = 6
    showhealth = 0
    showrounds = 0
    selfblankskipsopp = 0
    canshootself = 1
    canshootopp = 0
    maxlivecount = 1
    maxblankcount = int(magsize)-1
  elif mode == '3':
    lblprint("Game settings")
    dash()
    progress = 0
    while progress == 0:
      hp = input("Starting health points: ")
      try:
        if int(hp) < 1:
          progress = 0
          xlprint("Health cannot be less than 1.", 1)
        else:
          progress = 1
          hp = int(hp)
          print("")
      except:
        progress = 0
        xlprint("Invalid input type.", 1)
    progress = 0
    while progress == 0:
      magsize = input("Revolver round capacity: ")
      try:
        if int(magsize) < 4:
          progress = 0
          xlprint("Round capacity cannot be less than 4.", 1)
        else:
          progress = 1
          magsize = int(magsize)
          print("")
      except:
        progress = 0
        xlprint("Invalid input type.", 1)
    progress = 0
    while progress == 0:
      showhealth = input("Show health? (1 = Yes, 0 = No) ")
      try:
        if int(showhealth) < 0 or int(showhealth) > 1:
          progress = 0
          xlprint("Input cannot be anything other than 0 or 1", 1)
        else:
          progress = 1
          showhealth = int(showhealth)
          print("")
      except:
        progress = 0
        xlprint("Input cannot be anything other than 0 or 1", 1)
    progress = 0
    while progress == 0:
      showrounds = input("Show rounds? (1 = Yes, 0 = No) ")
      try:
        if int(showrounds) < 0 or int(showrounds) > 1:
          progress = 0
          xlprint("Input cannot be anything other than 0 or 1", 1)
        else:
          progress = 1
          showrounds  = int(showrounds)
          print("")
      except:
        progress = 0
        xlprint("Input cannot be anything other than 0 or 1", 1)
    progress = 0
    while progress == 0:
      selfblankskipsopp = input("Should shooting yourself with a blank skip the opponent's turn? (1 = Yes, 0 = No) ")
      try:
        if int(selfblankskipsopp) < 0 or int(selfblankskipsopp) > 1:
          progress = 0
          xlprint("Input cannot be anything other than 0 or 1", 1)
        else:
          progress = 1
          selfblankskipsopp = int(selfblankskipsopp)
          print("")
      except:
        progress = 0
        xlprint("Input cannot be anything other than 0 or 1", 1)
    progress = 0
    while progress == 0:
      blwprint("Who should you be able to shoot?", 0)
      print("1 - Only yourself")
      print("2 - Only the opponent")
      blwprint("3 - Both", 0)
      choice = input("Your choice: ")
      try:
        if int(choice) < 1 or int(choice) > 3:
          progress = 0
          xlprint("Input was out of bounds.", 1)
        else:
          progress = 1
          if input == 1:
            canshootself = 1
            canshootopp = 0
          elif input == 2:
            canshootself = 0
            canshootopp = 1
          else:
            canshootself = 0
            canshootopp = 1
          print("")
      except:
        progress = 0
        xlprint("Invalid input type.", 1)
    progress = 0
    while progress == 0:
      maxlivecount = input("Maximum number of live rounds: (input 'default' to set it to half the round capacity) ")
      try:
        if int(maxlivecount) < 1:
          progress = 0
          xlprint("Input cannot be less than 1", 1)
        else:
          progress = 1
          maxlivecount = int(maxlivecount)
          print("")
      except:
        if maxlivecount == 'default':
          progress = 1
          maxlivecount = int(int(magsize) / 2)
          print("")
        else:
          progress = 0
          xlprint("Invalid input type.", 1)
    progress = 0
    while progress == 0:
      maxblankcount = input("Maximum number of blanks: (input 'default' to set it to half the round capacity) ")
      try:
        if int(maxblankcount) < 1:
          progress = 0
          xlprint("Input cannot be less than 1", 1)
        else:
          progress = 1
          maxblankcount = int(maxblankcount)
          print("")
      except:
        if maxblankcount == 'default':
          progress = 1
          maxblankcount = int(int(magsize) / 2)
          print("")
        else:
          progress = 0
          xlprint("Invalid input type.", 1)
    blwprint("Customisation complete.", 1)
    input("Press enter to continue ")
  clear()
  blwprint("Enter your name:", 1)
  global name
  name = input()
  abvprint("Hello, " + name + ".", 1)
  dash()
  input("Press enter to continue ")
  clear()
  play()


def play():
  clear()
  global numoflives
  global numofblanks
  loadrounds("The revolver is being loaded.")
  global userplays
  if random.randrange(1, 3) == 1:
    userplays = 1
  else:
    userplays = 0

  global gameended
  global playerhealth
  global opphealth
  global hp
  global selfblankskipsopp
  global canshootself
  global canshootopp
  gameended = 0
  playerhealth = int(hp)
  opphealth = int(hp)
  firstround = 1
  while gameended == 0:
    clear()
    if playerhealth <= 0:
      gameended = 1
      lblprint("The opponent won.")
      break
    elif opphealth <= 0:
      winsound.PlaySound('vicroy.wav', winsound.SND_ASYNC)
      print(name + " won.")
      gameended = 1
      break
    if (numoflives + numofblanks) <= 0:
      loadrounds("The revolver is being reloaded.")
    gamestatus()
    if firstround == 1:
      firstround = 0
      if userplays == 0:
        blwprint("The opponent starts.", 1)
      else:
        blwprint("You start.", 1)
    if userplays == 0:
      userplays = 1
      opplays()
    else:
      while userplays == 1:
        if canshootself == 1 and canshootopp == 1:
          blwprint("Point the revolver towards: ", 0)
          print("1 - Yourself")
          blwprint("2 - The opponent", 0)
          choice = input("Your choice: ")
          if 1 < 2:
            if choice == '1':
              userplays = 0
              xlprint("You point the revolver at yourself...", 1)
              time.sleep(2.5)
              if rounds[0] == 0:
                winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
                print("click")
                rounds.pop(0)
                numofblanks -= 1
                userplays = 1
                break
              else:
                winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
                print("BANG")
                playerhealth -= 1
                rounds.pop(0)
                numoflives -= 1
                break
            elif choice == '2':
              userplays = 0
              xlprint("You point the revolver at the opponent...", 1)
              time.sleep(2.5)
              if rounds[0] == 0:
                winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
                print("click")
                rounds.pop(0)
                numofblanks -= 1
              else:
                winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
                print("BANG")
                opphealth -= 1
                rounds.pop(0)
                numoflives -= 1
              break
            abvprint("Invalid input type.", 1)
            dash()
            gamestatus()
        elif canshootself == 1:
          input("Press enter to shoot yourself ")
          userplays = 0
          xlprint("You point the revolver at yourself...", 1)
          time.sleep(2.5)
          if rounds[0] == 0:
            winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
            print("click")
            rounds.pop(0)
            numofblanks -= 1
            if selfblankskipsopp == 1:
              userplays = 1
            break
          else:
            winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
            print("BANG")
            playerhealth -= 1
            rounds.pop(0)
            numoflives -= 1
            break
        elif canshootopp == 1:
          input("Press enter to shoot the opponent ")
          userplays = 0
          xlprint("You point the revolver at the opponent...", 1)
          time.sleep(2.5)
          if rounds[0] == 0:
            winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
            print("click")
            rounds.pop(0)
            numofblanks -= 1
          else:
            winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
            print("BANG")
            opphealth -= 1
            rounds.pop(0)
            numoflives -= 1
          break
      print()
      input("Press enter to continue ")
  print()
  input("Press enter to continue ")
  main()


def opplays():
  global playerhealth
  global opphealth
  global numoflives
  global numofblanks
  global userplays
  global selfblankskipsopp
  global canshootself
  global canshootopp
  if numoflives > numofblanks and canshootopp == 1:
    blwprint("The opponent points the revolver at you...", 1)
    time.sleep(2.5)
    if rounds[0] == 0:
      winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
      print("click")
      rounds.pop(0)
      numofblanks -= 1
    else:
      winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
      print("BANG")
      playerhealth -= 1
      rounds.pop(0)
      numoflives -= 1
  elif numofblanks > numoflives and canshootself == 1:
    blwprint("The opponent points the revolver at themselves...", 1)
    time.sleep(2.5)
    if rounds[0] == 0:
      winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
      print("click")
      rounds.pop(0)
      numofblanks -= 1
      if selfblankskipsopp == 1:
        userplays = 0
    else:
      winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
      print("BANG")
      opphealth -= 1
      rounds.pop(0)
      numoflives -= 1
  elif random.randrange(1, 3) == 1 and canshootopp == 1:
    blwprint("The opponent points the revolver at you...", 1)
    time.sleep(2.5)
    if rounds[0] == 0:
      winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
      print("click")
      rounds.pop(0)
      numofblanks -= 1
    else:
      winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
      print("BANG")
      playerhealth -= 1
      rounds.pop(0)
      numoflives -= 1
  elif canshootself == 1:
    blwprint("The opponent points the revolver at themselves...", 1)
    time.sleep(2.5)
    if rounds[0] == 0:
      winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
      print("click")
      rounds.pop(0)
      numofblanks -= 1
      if selfblankskipsopp == 1:
        userplays = 0
    else:
      winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
      print("BANG")
      opphealth -= 1
      rounds.pop(0)
      numoflives -= 1
  elif canshootopp == 1:
    blwprint("The opponent points the revolver at you...", 1)
    time.sleep(2.5)
    if rounds[0] == 0:
      winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
      print("click")
      rounds.pop(0)
      numofblanks -= 1
    else:
      winsound.PlaySound('gunshot.wav', winsound.SND_ASYNC)
      print("BANG")
      playerhealth -= 1
      rounds.pop(0)
      numoflives -= 1
  print()
  input("Press enter to continue ")


def gamestatus():
  global numoflives
  global numofblanks
  global rounds
  global totalrounds
  global playerhealth
  global opphealth
  global showhealth
  global showrounds
  if showhealth == 1:
    playerhealthtext = ""
    opphealthtext = ""
    for i in range(playerhealth):
      playerhealthtext += "X "
    for i in range(opphealth):
      opphealthtext += "X "
    print(name)
    blwprint(playerhealthtext, 0)
    print("Opponent")
    print(opphealthtext)
  if showrounds == 1:
    print("")
    if numoflives == 1:
      print(str(numoflives) + " live round, ", end="")
    else:
      print(str(numoflives) + " live rounds, ", end="")
    if numofblanks == 1:
      print(str(numofblanks) + " blank.")
    else:
      print(str(numofblanks) + " blanks.")
  if showhealth == 1 or showrounds == 1:
    dash()


def loadrounds(text):
  global numoflives
  global numofblanks
  global magsize
  global selfblankskipsopp
  global maxlivecount
  global maxblankcount
  if maxlivecount == 'default':
    numoflives = random.randrange(1, int(int(magsize) / 2))
  else:
    numoflives = random.randrange(1, maxlivecount+1)
  if maxblankcount == 'default':
    numofblanks = random.randrange(1, int(int(magsize) / 2))
  else:
    numofblanks = random.randrange(1, maxblankcount+1)

  while (numoflives + numofblanks) < int(magsize):
    try:
      if random.randrange(1, 3) == 1 and numoflives < int(maxlivecount):
        numoflives += 1
      elif numofblanks < int(maxblankcount):
        numofblanks += 1
      else:
        break
    except:
      if random.randrange(1, 3) == 1:
        numoflives += 1
      else:
        numofblanks += 1

  fakenumoflives = numoflives
  fakenumofblanks = numofblanks
  global totalrounds
  totalrounds = numoflives + numofblanks
  global rounds
  rounds = [0] * (totalrounds)

  for i in range(totalrounds):
    if (random.randrange(1, 3) == 1) and (fakenumoflives > 0):
      rounds[i] = 1
      fakenumoflives -= 1
    elif fakenumofblanks > 0:
      rounds[i] = 0
      fakenumofblanks -= 1
    elif fakenumoflives > 0:
      rounds[i] = 1
      fakenumoflives -= 1

  blwprint(text, 1)
  for i in range(totalrounds):
    time.sleep(0.5)
    winsound.PlaySound('blank.wav', winsound.SND_ASYNC)
    print("O ", end="", flush=True)
  time.sleep(0.5)
  winsound.PlaySound('load.wav', winsound.SND_FILENAME)
  time.sleep(0.5)
  blwprint("", 0)
  if numoflives == 1:
    print(str(numoflives) + " live round, ", end="")
  else:
    print(str(numoflives) + " live rounds, ", end="")
  if numofblanks == 1:
    print(str(numofblanks) + " blank.")
  else:
    print(str(numofblanks) + " blanks.")
  print()
  if selfblankskipsopp == 1:
    lblprint("Remember, shooting yourself with a blank shot skips the opponent's turn.")
    print()
  input("Press enter to continue ")
  clear()


os.chdir(os.path.dirname(os.path.abspath(__file__)))
clear()
main()